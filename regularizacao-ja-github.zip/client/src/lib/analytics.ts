/**
 * Google Analytics 4 Event Tracking
 * Utilitário para rastrear eventos no Google Analytics
 */

declare global {
  interface Window {
    gtag: (command: string, ...args: any[]) => void;
  }
}

/**
 * Rastreia um evento customizado no Google Analytics
 */
export const trackEvent = (
  eventName: string,
  eventData?: Record<string, any>
) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', eventName, eventData);
  }
};

/**
 * Rastreia submissão de formulário
 */
export const trackFormSubmission = (formName: string) => {
  trackEvent('form_submit', {
    form_name: formName,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Rastreia clique em CTA (Call To Action)
 */
export const trackCTAClick = (ctaName: string, ctaText?: string) => {
  trackEvent('cta_click', {
    cta_name: ctaName,
    cta_text: ctaText,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Rastreia navegação entre seções
 */
export const trackSectionView = (sectionName: string) => {
  trackEvent('section_view', {
    section_name: sectionName,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Rastreia clique em plano
 */
export const trackPlanClick = (planName: string, planPrice: string) => {
  trackEvent('plan_click', {
    plan_name: planName,
    plan_price: planPrice,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Rastreia clique em link de contato
 */
export const trackContactClick = (contactType: string) => {
  trackEvent('contact_click', {
    contact_type: contactType,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Rastreia scroll depth (profundidade de rolagem)
 */
export const trackScrollDepth = (depth: number) => {
  trackEvent('scroll_depth', {
    scroll_percentage: depth,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Rastreia visualização de página
 */
export const trackPageView = (pageName: string) => {
  trackEvent('page_view', {
    page_name: pageName,
    page_path: window.location.pathname,
    timestamp: new Date().toISOString(),
  });
};
