import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Trash2, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [location, navigate] = useLocation();
  const { data: forms, isLoading, refetch } = trpc.contact.list.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  });
  const deleteForm = trpc.contact.delete.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  useEffect(() => {
    if (isAuthenticated && user?.role !== 'admin') {
      navigate('/');
    }
  }, [isAuthenticated, user]);

  if (!isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 text-center">
          <p className="text-foreground mb-4">Acesso restrito a administradores</p>
          <Button onClick={() => navigate('/')}>Voltar para Início</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Painel de Admin</h1>
          <p className="text-muted-foreground">Gerenciar formulários de contato</p>
        </div>

        <Card className="p-6">
          <h2 className="text-2xl font-bold text-foreground mb-6">Formulários Recebidos</h2>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="animate-spin text-primary" size={32} />
            </div>
          ) : forms && forms.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Nome</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Telefone</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Email</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Data</th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {forms.map((form) => (
                    <tr key={form.id} className="border-b border-border hover:bg-muted/50 transition">
                      <td className="py-3 px-4 text-foreground">{form.name}</td>
                      <td className="py-3 px-4 text-foreground">
                        <a
                          href={`https://wa.me/55${form.phone.replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          {form.phone}
                        </a>
                      </td>
                      <td className="py-3 px-4 text-foreground">
                        <a href={`mailto:${form.email}`} className="text-primary hover:underline">
                          {form.email}
                        </a>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(form.createdAt).toLocaleDateString('pt-BR', {
                          year: 'numeric',
                          month: '2-digit',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3 px-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteForm.mutate({ id: form.id })}
                          disabled={deleteForm.isPending}
                          className="text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-12 text-center">
              <p className="text-muted-foreground">Nenhum formulário recebido ainda</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
