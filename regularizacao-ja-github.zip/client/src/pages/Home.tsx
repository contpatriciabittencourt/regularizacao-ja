import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { trackFormSubmission, trackCTAClick, trackPlanClick, trackContactClick, trackScrollDepth } from "@/lib/analytics";
import {
  Menu,
  X,
  CheckCircle,
  Users,
  TrendingUp,
  Award,
  FileText,
  DollarSign,
  Scale,
  Briefcase,
  Phone,
  Mail,
  MapPin,
  Clock,
  Instagram,
  MessageCircle,
  Star,
} from "lucide-react";

// Componente de Carousel de Galeria
function GalleryCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const images = [
    { id: 1, src: '/gallery-1.jpg', alt: 'Evento contábil com participação de profissionais' },
    { id: 2, src: '/gallery-2.jpg', alt: 'Patrícia apresentando no evento do CRCAL' },
    { id: 3, src: '/gallery-3.jpg', alt: 'Participação em evento de mulheres empreendedoras' },
    { id: 4, src: '/gallery-4.jpg', alt: 'Encontro com profissionais da área contábil' },
    { id: 5, src: '/gallery-5.jpg', alt: 'Capacitação profissional em Arapiraca' },
    { id: 6, src: '/gallery-6.jpg', alt: 'Patrícia em evento de desenvolvimento profissional' },
  ];

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <section id="galeria" className="py-16 md:py-24 bg-background" role="region" aria-label="Galeria de eventos e capacitações">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Galeria de Eventos e Capacitações
          </h2>
          <p className="text-lg text-muted-foreground">
            Participações em eventos contábeis e capacitações profissionais
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Carousel Container */}
          <div className="relative overflow-hidden rounded-lg shadow-2xl flex items-center justify-center bg-muted/20 min-h-96">
            {images.map((image, index) => (
              <div
                key={image.id}
                className={`absolute transition-opacity duration-500 ${
                  index === currentIndex ? 'opacity-100' : 'opacity-0'
                }`}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="max-w-full max-h-96 h-auto w-auto"
                />
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-primary/80 hover:bg-primary text-primary-foreground p-3 rounded-full transition-all"
            aria-label="Foto anterior"
          >
            ←
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-primary/80 hover:bg-primary text-primary-foreground p-3 rounded-full transition-all"
            aria-label="Próxima foto"
          >
            →
          </button>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-6">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentIndex ? 'bg-primary w-8' : 'bg-primary/40'
                }`}
                aria-label={`Ir para foto ${index + 1}`}
              />
            ))}
          </div>

          {/* Image Description */}
          <p className="text-center mt-6 text-muted-foreground">
            {images[currentIndex].alt}
          </p>
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  const { user, loading, error, isAuthenticated, logout } = useAuth();
  const submitContactForm = trpc.contact.submit.useMutation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    cnpj: "",
    phone: "",
    email: "",
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.cnpj) {
      try {
        trackFormSubmission('regularizacao_form');
        const message = `Oi, me chamo ${formData.name}; Quero regularizar meu Negócio! CNPJ ${formData.cnpj}`;
        const whatsappUrl = `https://wa.me/5582999657538?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, "_blank");
        setFormSubmitted(true);
        setTimeout(() => {
          setFormData({ name: "", cnpj: "", phone: "", email: "" });
          setFormSubmitted(false);
        }, 3000);
      } catch (error) {
        console.error("Erro ao enviar formulário:", error);
      }
    }
  };

  const services = [
    {
      icon: Briefcase,
      title: "Abertura de Empresa",
      description: "Constituição legal e registro em órgãos competentes",
    },
    {
      icon: FileText,
      title: "Regularização Fiscal",
      description: "Alinhamento com obrigações tributárias federais",
    },
    {
      icon: DollarSign,
      title: "Declarações Obrigatórias",
      description: "ECF, DCTF, GIAS e outras declarações em dia",
    },
    {
      icon: Award,
      title: "Certidões Negativas",
      description: "Obtenção de certidões junto aos órgãos públicos",
    },
    {
      icon: TrendingUp,
      title: "Enquadramento Tributário",
      description: "Escolha do regime mais vantajoso para seu negócio",
    },
    {
      icon: Scale,
      title: "Regularização Trabalhista",
      description: "Conformidade com legislação trabalhista e previdenciária",
    },
  ];

  const benefits = [
    {
      icon: Clock,
      title: "Economia de Tempo",
      description: "Deixe conosco toda a burocracia e foque no seu negócio",
    },
    {
      icon: Award,
      title: "Especialistas Certificados",
      description: "Equipe com experiência e conhecimento atualizado",
    },
    {
      icon: DollarSign,
      title: "Preços Competitivos",
      description: "Soluções acessíveis para empresas de todos os tamanhos",
    },
    {
      icon: Users,
      title: "Atendimento Personalizado",
      description: "Dedicação exclusiva ao seu caso e necessidades específicas",
    },
  ];

  const testimonials = [
    {
      name: "Marina Costa",
      company: "Consultoria Empresarial",
      text: "Excelente atendimento e resultados rápidos. Recomendo para qualquer empresário que precisa regularizar.",
      rating: 5,
    },
    {
      name: "Roberto Santos",
      company: "Comércio Geral",
      text: "Consegui reduzir significativamente meus custos fiscais com as orientações da Patrícia.",
      rating: 5,
    },
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <img src="/logo-full.png" alt="Logo Regularização Já - Patrícia Bittencourt Contadora" className="h-20 w-auto" />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8" role="navigation" aria-label="Menu principal">
            <button
              onClick={() => scrollToSection("inicio")}
              className="text-foreground hover:text-primary font-medium transition"
            >
              Início
            </button>
            <button
              onClick={() => scrollToSection("servicos")}
              className="text-foreground hover:text-primary font-medium transition"
            >
              Serviços
            </button>
            <button
              onClick={() => scrollToSection("sobre")}
              className="text-foreground hover:text-primary font-medium transition"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection("contato")}
              className="text-foreground hover:text-primary font-medium transition"
            >
              Contato
            </button>
          </nav>

          {/* CTA Buttons */}
          <div className="hidden sm:flex gap-3">
            <Button
              onClick={() => {
                trackCTAClick('fale_conosco_header');
                window.open('https://wa.me/5582999657538?text=Ol%C3%A1%21%20Gostaria%20de%20conversar%20sobre%20meu%20neg%C3%B3cio.', '_blank');
              }}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              Fale Conosco
            </Button>
            <Button
              onClick={() => {
                trackCTAClick('abrir_cnpj_header');
                const message = 'Ol%C3%A1%21%20Tenho%20interesse%20em%20abrir%20meu%20primeiro%20CNPJ.%20Gostaria%20de%20saber%20mais%20sobre%20os%20servi%C3%A7os%20de%20abertura%20de%20empresa.';
                window.open(`https://wa.me/5582999657538?text=${message}`, '_blank');
              }}
              className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
            >
              Quero Abrir um CNPJ
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-foreground"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-border">
            <nav className="container flex flex-col gap-4 py-4" role="navigation" aria-label="Menu móvel">
              <button
                onClick={() => scrollToSection("inicio")}
                className="text-left text-foreground hover:text-primary font-medium"
              >
                Início
              </button>
              <button
                onClick={() => scrollToSection("servicos")}
                className="text-left text-foreground hover:text-primary font-medium"
              >
                Serviços
              </button>
              <button
                onClick={() => scrollToSection("sobre")}
                className="text-left text-foreground hover:text-primary font-medium"
              >
                Sobre
              </button>
              <button
                onClick={() => scrollToSection("contato")}
                className="text-left text-foreground hover:text-primary font-medium"
              >
                Contato
              </button>
              <Button
                onClick={() => {
                  trackCTAClick('fale_conosco_mobile_menu');
                  window.open('https://wa.me/5582999657538?text=Ol%C3%A1%21%20Gostaria%20de%20conversar%20sobre%20meu%20neg%C3%B3cio.', '_blank');
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Fale Conosco
              </Button>
              <Button
                onClick={() => {
                  trackCTAClick('abrir_cnpj_mobile_menu');
                  window.open('https://wa.me/5582999657538?text=Ol%C3%A1%21%20Tenho%20interesse%20em%20abrir%20meu%20primeiro%20CNPJ.%20Gostaria%20de%20saber%20mais%20sobre%20os%20servi%C3%A7os.', '_blank');
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-secondary hover:bg-secondary/90 text-primary-foreground"
              >
                Quero Abrir um CNPJ
              </Button>
            </nav>
          </div>
        )}
      </header>

      <main className="flex-1">
         {/* Hero Section */}
        <section id="inicio" className="py-16 md:py-24 bg-gradient-to-br from-primary to-secondary text-primary-foreground" role="region" aria-label="Seção principal">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                  Regularize sua empresa de forma rápida e segura
                </h1>
                <p className="text-lg md:text-xl mb-8 opacity-95">
                  Evite multas e problemas fiscais com nossos especialistas. Deixe a burocracia conosco!
                </p>
              </div>

              {/* Form */}
              <Card className="bg-white p-8 shadow-lg">
                <h2 className="text-2xl font-bold text-foreground mb-6">Quero Regularizar</h2>
                <form onSubmit={handleFormSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Nome
                    </label>
                    <Input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleFormChange}
                      placeholder="Seu nome completo"
                      required
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      CNPJ
                    </label>
                    <Input
                      type="text"
                      name="cnpj"
                      value={formData.cnpj}
                      onChange={handleFormChange}
                      placeholder="XX.XXX.XXX/0001-XX"
                      required
                      className="w-full"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-3"
                  >
                    {formSubmitted ? "✓ Mensagem Enviada!" : "Quero Regularizar"}
                  </Button>
                </form>
              </Card>
            </div>
          </div>
        </section>

        {/* Serviços Section */}
        <section id="servicos" className="py-16 md:py-24 bg-background" role="region" aria-label="Nossos serviços">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Nossos Serviços
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Soluções completas para regularizar sua empresa em todas as esferas
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <Card key={index} className="p-6 hover:shadow-lg transition">
                    <div className="flex items-start gap-4">
                      <div className="bg-primary/10 p-3 rounded-lg">
                        <IconComponent className="text-primary" size={28} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-foreground mb-2">
                          {service.title}
                        </h3>
                        <p className="text-muted-foreground">{service.description}</p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Planos Section */}
        <section id="planos" className="py-16 md:py-24 bg-background" role="region" aria-label="Planos de acompanhamento">
          <div className="container">
            <div className="text-center mb-4">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Planos de Acompanhamento para MEI
              </h2>
              <p className="text-xl text-primary font-bold mb-12">
                Foque no seu negócio, que a burocracia a gente DESCOMPLICA
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {/* Plano START */}
              <Card className="p-8 border-2 border-border hover:shadow-lg transition">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">START</h3>
                  <div className="text-4xl font-bold text-primary mb-4">R$ 147,90</div>
                  <p className="text-sm text-muted-foreground">por mês</p>
                </div>
                <div className="space-y-3 mb-8">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Acompanhamento de Faturamento</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Emissão do DAS</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Envio da Declaração Anual</span>
                  </div>
                </div>
                <Button
                  onClick={() => {
                    trackPlanClick('START', 'R$ 147,90');
                    const message = "Olá! Tenho interesse no plano START (R$ 147,90/mês). Gostaria de saber mais detalhes.";
                    window.open(`https://wa.me/5582999657538?text=${encodeURIComponent(message)}`, "_blank");
                  }}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Escolher Plano
                </Button>
              </Card>

              {/* Plano SMART */}
              <Card className="p-8 border-2 border-border hover:shadow-lg transition">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">SMART</h3>
                  <div className="text-4xl font-bold text-primary mb-4">R$ 247,90</div>
                  <p className="text-sm text-muted-foreground">por mês</p>
                </div>
                <div className="space-y-3 mb-8">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Acompanhamento de Faturamento</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Consultoria Mensal (1 hora)</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">DAR Interestadual</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Emissão do DAS</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Emissão de Notas Fiscais</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Envio da Declaração Anual</span>
                  </div>
                </div>
                <Button
                  onClick={() => {
                    trackPlanClick('SMART', 'R$ 247,90');
                    const message = "Olá! Tenho interesse no plano SMART (R$ 247,90/mês). Gostaria de saber mais detalhes.";
                    window.open(`https://wa.me/5582999657538?text=${encodeURIComponent(message)}`, "_blank");
                  }}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Escolher Plano
                </Button>
              </Card>

              {/* Plano STAR */}
              <Card className="p-8 border-2 border-primary hover:shadow-lg transition relative">
                <div className="absolute -top-6 -right-6 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground w-24 h-24 rounded-full flex items-center justify-center shadow-lg hover:shadow-2xl transition-shadow">
                  <Star size={48} fill="currentColor" className="animate-pulse" />
                </div>
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-primary mb-2">STAR</h3>
                  <div className="text-4xl font-bold text-primary mb-4">R$ 347,90</div>
                  <p className="text-sm text-muted-foreground">por mês</p>
                </div>
                <div className="space-y-3 mb-8">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Acompanhamento de Faturamento</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Consultoria Mensal</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Contabilidade Regular</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">DAR Interestadual</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Emissão do DAS</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Emissão de Notas Fiscais</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Envio da Declaração Anual</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                    <span className="text-foreground">Gestão de Empregados</span>
                  </div>
                </div>
                <Button
                  onClick={() => {
                    trackPlanClick('STAR', 'R$ 347,90');
                    const message = "Olá! Tenho interesse no plano STAR (R$ 347,90/mês). Gostaria de saber mais detalhes.";
                    window.open(`https://wa.me/5582999657538?text=${encodeURIComponent(message)}`, "_blank");
                  }}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Escolher Plano
                </Button>
              </Card>
            </div>
          </div>
        </section>

        {/* Benefícios Section */}
        <section id="beneficios" className="py-16 md:py-24 bg-muted/30" role="region" aria-label="Por que escolher nossa contadora">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Por que escolher nossa contadora?
              </h2>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {benefits.map((benefit, index) => {
                const IconComponent = benefit.icon;
                return (
                  <Card key={index} className="p-6 text-center">
                    <div className="bg-primary/10 p-4 rounded-lg w-fit mx-auto mb-4">
                      <IconComponent className="text-primary" size={32} />
                    </div>
                    <h3 className="text-lg font-bold text-foreground mb-2">
                      {benefit.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Sobre Section */}
        <section id="sobre" className="py-16 md:py-24 bg-background" role="region" aria-label="Sobre Patrícia Bittencourt">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                  Sobre Patrícia Bittencourt
                </h2>
                <p className="text-lg text-muted-foreground mb-4">
                  Com experiência no segmento desde 2012, Patrícia Bittencourt possui vasto domínio das áreas de departamento fiscal, pessoal e contábil. Dedicada a ajudar pequenos e médios empresários a regularizar suas situações fiscais, trabalhistas e tributárias.
                </p>
                <p className="text-lg text-muted-foreground mb-6">
                  Especializada em soluções personalizadas, ela oferece atendimento profissional e acessível, com foco em resolver problemas e evitar multas desnecessárias.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="text-primary" size={24} />
                    <span className="text-foreground font-medium">
                      Contadora especialista
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="text-primary" size={24} />
                    <span className="text-foreground font-medium">
                      MBA - Contabilidade, Compliance & Direito Tributário
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="text-primary" size={24} />
                    <span className="text-foreground font-medium">
                      Técnica em Recursos Humanos
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex justify-center">
                <img
                  src="/patricia-photo.png"
                  alt="Patrícia Bittencourt - Contadora Especializada"
                  className="rounded-lg shadow-lg max-w-sm w-full object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Depoimentos Section */}
        <section id="depoimentos" className="py-16 md:py-24 bg-muted/30" role="region" aria-label="Depoimentos de clientes">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                O que nossos clientes dizem
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <span key={i} className="text-yellow-400 text-lg">
                        ★
                      </span>
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">"{testimonial.text}"</p>
                  <div>
                    <p className="font-bold text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Galeria Section */}
        <GalleryCarousel />

        {/* Botão Flutuante de WhatsApp */}
        <a
          href="https://wa.me/5582999657538"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 z-40 bg-primary text-primary-foreground p-4 rounded-full shadow-lg hover:shadow-xl hover:bg-primary/90 transition-all duration-300 flex items-center justify-center"
          aria-label="Fale conosco no WhatsApp"
          onClick={() => trackContactClick('whatsapp_floating_button')}
        >
          <MessageCircle size={28} fill="currentColor" />
        </a>
      </main>

      {/* Footer */}
      <footer id="contato" className="bg-primary text-primary-foreground py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Contato */}
            <div>
              <h3 className="text-lg font-bold mb-4">Contato</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Phone size={20} />
                  <a href="https://wa.me/5582999657538" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition" onClick={() => trackContactClick('whatsapp_footer')}>
                    (82) 99965-7538
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <Mail size={20} />
                  <a href="mailto:cont.patriciabittencourt@gmail.com" className="hover:text-primary transition" onClick={() => trackContactClick('email_footer')}>
                    cont.patriciabittencourt@gmail.com
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin size={20} />
                  <span>Maceió, AL</span>
                </div>
              </div>
            </div>

            {/* Horário */}
            <div>
              <h3 className="text-lg font-bold mb-4">Horário de Atendimento</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Clock size={20} />
                  <span>Segunda a Sexta</span>
                </div>
                <p className="ml-8">08:00 - 18:00</p>
                <div className="flex items-center gap-3 mt-4">
                  <MessageCircle size={20} />
                  <span>WhatsApp 24h</span>
                </div>
              </div>
            </div>

            {/* Redes Sociais */}
            <div>
              <h3 className="text-lg font-bold mb-4">Redes Sociais</h3>
              <div className="flex gap-4">
                <a
                  href="https://www.instagram.com/cont.patriciabittencourt/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary-foreground/20 p-3 rounded-lg hover:bg-primary-foreground/30 transition"
                  aria-label="Instagram"
                  onClick={() => trackContactClick('instagram')}
                >
                  <Instagram size={20} />
                </a>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-primary-foreground/20 pt-8">
            {/* Formulário de Contato Reduzido */}
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-4">Fale Conosco</h3>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/5582999657538"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1"
                >
                  <Button className="w-full bg-primary-foreground text-primary hover:bg-primary-foreground/90">
                    Enviar Mensagem WhatsApp
                  </Button>
                </a>
              </div>
            </div>

            {/* Copyright */}
            <div className="text-center text-sm opacity-80">
              <p>
                © 2024 Regularização Já - Patrícia Bittencourt. Todos os direitos reservados.
              </p>
              <p className="mt-2">
                Desenvolvido com ❤️ para regularizar sua empresa
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
